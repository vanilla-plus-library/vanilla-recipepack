# Vanilla+ Library: Block Placement

Add a mechanic to simulate block placements using item frames and blast furnaces.

## Requirements
- Minecraft 1.16+.
- [Vanilla+ Library: Core](https://github.com/TheWii/vanilla-plus-library/tree/master/vplib-core-datapack)

## Releases
- [v1(latest)](https://github.com/TheWii/vanilla-plus-library/raw/master/releases/block-placement/vplib-block-placement-datapack-v1.zip)