# Vanilla+ Library: Block Placement

Add a mechanic to simulate block placements using item frames and blast furnaces.

## Requirements
- Minecraft 1.16+.
- [Vanilla+ Library: Core](https://github.com/TheWii/vanilla-plus-library/tree/master/vplib-core-datapack)

## Releases
- v1(incomplete)