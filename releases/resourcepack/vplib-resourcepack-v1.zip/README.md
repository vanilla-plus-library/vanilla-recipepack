# Vanilla+ Library: Resource Pack

Vanilla+ Library Resource Pack used by some modules.

## Requirements
- Minecraft 1.16+.

## Releases
- [v1(latest)](https://github.com/TheWii/vanilla-plus-library/raw/master/releases/resourcepack/vplib-resourcepack-v1.zip)