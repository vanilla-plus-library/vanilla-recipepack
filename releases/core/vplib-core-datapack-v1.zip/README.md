# Vanilla+ Library: Core

Manages and unifies all the modules from this library.

## Requirements
- Minecraft 1.16+.

## Releases
- v1(latest)